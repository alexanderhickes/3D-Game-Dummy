﻿using System;
using Mogre;

namespace Tutorial
{
    abstract class StaticElement : GameElement
    {

        public override void SetPosition(Vector3 position)
        {
            base.SetPosition(position);
        }
    }
}
