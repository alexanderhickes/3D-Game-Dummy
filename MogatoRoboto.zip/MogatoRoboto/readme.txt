This file adds HLSL styling support to Notepad++. It is released into the 
public domain by the author, Jon Watte.
For updates and discussion, see http://www.enchantedage.com/node/97
For information about notepad++, see http://notepad-plus.sourceforge.net/
