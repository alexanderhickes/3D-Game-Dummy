﻿using System;
using Mogre;

namespace Tutorial
{
    class Wall : StaticElement
    {
    }
}
