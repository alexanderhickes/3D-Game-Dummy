﻿using System;
using System.Collections.Generic;
using Mogre;

namespace Tutorial
{
    class Collectable : MovableElement
    {
        virtual public void Update(FrameEvent evt) { }
    }
}
