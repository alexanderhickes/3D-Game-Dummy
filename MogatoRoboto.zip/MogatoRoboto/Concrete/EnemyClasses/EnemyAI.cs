﻿using Mogre;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Tutorial
{
    class EnemyAI
    {
        private Timer timer;
        private int maxTime;
    }
}
