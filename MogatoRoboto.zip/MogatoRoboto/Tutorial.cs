﻿using Mogre;
using Mogre.TutorialFramework;
using System;
using System.Collections.Generic;
using PhysicsEng;

namespace Tutorial
{
    class Tutorial: BaseApplication
    {
        public static void Main()
        {
          //new Level1().Go();
          new Level2().Go();
          //new Level3().Go();

        }
    }
}
