﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Mogre;

namespace Tutorial
{
    class GeometryLoader
    {
        SceneManager mSceneManager;
        //Entity geometryEntity;
        //SceneNode geometryNode;
        //---------------------------

        Entity power;
        Entity hull;
        Entity sphere;

        SceneNode hullGroupNode;
        SceneNode wheelsGroupNode;
        SceneNode gunsGroupNode;

        SceneNode model;                            // Root for the sub-graph

        /// <summary>
        /// This method returns the root node for the sub-scenegraph representing the compound model
        /// </summary>
        public SceneNode Model
        {
            get { return model; }
        }

        Radian angle;
        Vector3 direction;
        float radius;

        const float maxTime = 2000f;        // Time when the animation have to be changed
        Timer time;                         // Timer for animation changes
        AnimationState animationState;      // Animation state, retrieves and store an animation from an Entity
        bool animationChanged;              // Flag which tells when the mesh animation has changed

        string animationName;               // Name of the animation to use
        public string AnimationName
        {
            set
            {
                HasAnimationChanged(value);
                if (IsValidAnimationName(value))
                    animationName = value;
                else
                    animationName = "Idle";
            }
        }

        public Vector3 Position
        {
            get { return hullGroupNode.Position; }
        }

        public GeometryLoader(SceneManager mSceneManager, String mesh)
        {
            this.mSceneManager = mSceneManager;
            Load(mesh);
        }

        private void Load(String mesh)
        {
            //geometryEntity = mSceneManager.CreateEntity(mesh);
            //geometryNode = mSceneManager.CreateSceneNode();
            //geometryNode.AttachObject(geometryEntity);
            //mSceneManager.RootSceneNode.AddChild(geometryNode);
            //---------------------------------------------------

            power = mSceneManager.CreateEntity("PowerCells.mesh");
            hull = mSceneManager.CreateEntity("Main.mesh");
            sphere = mSceneManager.CreateEntity("Sphere.mesh");

            hullGroupNode = mSceneManager.CreateSceneNode();
                hullGroupNode.AttachObject(power);
                hullGroupNode.AttachObject(hull);
            wheelsGroupNode = mSceneManager.CreateSceneNode();
                wheelsGroupNode.AttachObject(sphere);
            gunsGroupNode = mSceneManager.CreateSceneNode();

            hullGroupNode.AddChild(wheelsGroupNode);
            hullGroupNode.AddChild(gunsGroupNode);

            mSceneManager.RootSceneNode.AddChild(hullGroupNode);

        }

        public void Animate(FrameEvent evt)
        {
            CircularMotion(evt);
            AnimateMesh(evt);
        }

        private void AnimationSetup()
        {
            radius = 0.01f;
            direction = Vector3.ZERO;
            angle = 0f;

            time = new Timer();
            PrintAnimationNames();
            animationChanged = false;
            animationName = "Walk";
            LoadAnimation();
        }

        private void HasAnimationChanged(string newName)
        {
            if (newName != animationName)
                animationChanged = true;
        }

        private void PrintAnimationNames()
        {
            AnimationStateSet animStateSet = hull.AllAnimationStates;     // Getd the set of animation states in the Entity
            AnimationStateIterator animIterator = animStateSet.GetAnimationStateIterator();  // Iterates through the animation states

            while (animIterator.MoveNext())                                       // Gets the next animation state in the set
            {
                Console.WriteLine(animIterator.CurrentKey);                      // Print out the animation name in the current key
            }
        }

        private bool IsValidAnimationName(string newName)
        {
            bool nameFound = false;

            AnimationStateSet animStateSet = hull.AllAnimationStates;
            AnimationStateIterator animIterator = animStateSet.GetAnimationStateIterator();

            while (animIterator.MoveNext() && !nameFound)
            {
                if (newName == animIterator.CurrentKey)
                {
                    nameFound = true;
                }
            }

            return nameFound;
        }

        private void changeAnimationName()
        {
            switch ((int)Mogre.Math.RangeRandom(0, 4.5f))       // Gets a random number between 0 and 4.5f
            {
                case 0:
                    {
                        AnimationName = "Walk";                 // I use the porperty here instead of the field to determine whether I am actualy changing the animation
                        break;
                    }
                case 1:
                    {
                        AnimationName = "Shoot";
                        break;
                    }
                case 2:
                    {
                        AnimationName = "Idle";
                        break;
                    }
                case 3:
                    {
                        AnimationName = "Slump";
                        break;
                    }
                case 4:
                    {
                        AnimationName = "Die";
                        break;
                    }
                    //case 5:
                    //    {
                    //        AnimationName = "Walk";
                    //        AnimationName = "Die";
                    //        break;
                    //    }
            }
        }

        private void LoadAnimation()
        {
            animationState = hull.GetAnimationState(animationName);
            animationState.Loop = true;
            animationState.Enabled = true;
        }

        private void CircularMotion(FrameEvent evt)
        {
            angle += (Radian)evt.timeSinceLastFrame;
            direction = radius * new Vector3(Mogre.Math.Cos(angle), 0, Mogre.Math.Sin(angle));
            hullGroupNode.Translate(direction);
            hullGroupNode.Yaw(-evt.timeSinceLastFrame);
            //hullGroupNode.Pitch(-evt.timeSinceLastFrame);
            //hullGroupNode.Roll(-evt.timeSinceLastFrame);
        }

        private void AnimateMesh(FrameEvent evt)
        {
            if (time.Milliseconds > maxTime)
            {
                changeAnimationName();
                time.Reset();
            }

            if (animationChanged)
            {
                LoadAnimation();
                animationChanged = false;
            }

            animationState.AddTime(evt.timeSinceLastFrame);
        }

        public void AddChild(SceneNode child)
        {
            hullGroupNode.AddChild(child);
        }

        public void Dispose()
        {
            //geometryNode.Parent.RemoveChild(geometryNode);
            //geometryNode.DetachAllObjects();
            //geometryNode.Dispose();
            //geometryEntity.Dispose();
        }

        public void Move(Vector3 direction)
        {
            hullGroupNode.Translate(direction);
        }

        public void Rotate(Vector3 angles)
        {
            hullGroupNode.Yaw(angles.x);
        }
    }
}
